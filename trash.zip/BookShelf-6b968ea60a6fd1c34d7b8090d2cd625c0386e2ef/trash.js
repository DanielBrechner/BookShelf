
const inputSearch = document.querySelector("#input-search");
const apiKey = "AIzaSyB8fcAyf3t4-OA-UVRQr5lI5pDcecw9vT4";



async function getBooks() {
    const searchPhrase = inputSearch.value;
    let url = `https://www.googleapis.com/books/v1/volumes?q=${searchPhrase}&maxResults=10&key=${apiKey}`;
    try {
        let res = await fetch(url);
        return await res.json();
    } catch (error) {
        console.log(error);
    }
}

async function renderBooks() {
  let books = await getBooks();
  books = books.items;
  let html = "";
  // console.log(books.items);
  books.forEach((book) => {
    console.log(book.volumeInfo.imageLinks);
    let htmlSegment = `<div class="book">
    <img src="${book.volumeInfo.imageLinks.thumbnail}" />
        <p>${book.kind}</p>        
        <p>${book.id}</p>
        <p>${book.etag}</p>
        <p>${book.selfLink}</p>

        </div>`;
    html += htmlSegment;
  });

  let container = document.querySelector(".savedBooks");
  container.innerHTML = html;
}


// renderBooks();