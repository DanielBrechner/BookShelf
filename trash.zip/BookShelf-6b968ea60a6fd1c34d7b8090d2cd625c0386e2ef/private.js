const info = {
    API_KEY: "vcxvscvxcvxc", 
    model:"500", 
    color:"white"
};
